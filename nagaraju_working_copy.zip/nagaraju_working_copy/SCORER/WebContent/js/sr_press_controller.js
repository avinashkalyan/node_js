var srAngCntxt={};
var srPressOrderListAllControllerJS = {
		init:function(){
			//initialization
			srAngCntxt.scope.userInput = {deliveryDetails:{},paymentDetails:{}};
			srAngCntxt.scope.selectedOrderDetails = {};
			srAngCntxt.scope.dealerList = [];
			srAngCntxt.srPressService.getAllOrders().then(
			          function(response) { 
			        	  load_PressAllOrdersDTB(response.data.allOrders);
			        	  srAngCntxt.scope.dealerList = response.data.dealerList;
			          },
			          function(errorPayload) {
			        	  load_PressAllOrdersDTB([]);
			          }
			);
			//attachEvents
			$(document).on('click', '.addDeliveryDetails', function () {
				 $("#delveryDet_myModal").modal({backdrop: "static"});
				 load_inputDeliveryProductDetDTB();
				 return false;
			});
			$(document).on('click', '.addPaymentDetails', function () {
				$("#paymentDet_myModal").modal({backdrop: "static"});
				return false;
			} );
		}
};
var srPressOrderCreateJS = {
		init:function(){
			//initialization
			srAngCntxt.scope.createOrderInput = {
					selectedProductList:staticSelectedProductList,
					selectedProductListInput:staticselectedProductListInput,
					totalAmount:0};
			srAngCntxt.scope.pressList = [];
			srAngCntxt.scope.productList = [];
			srAngCntxt.srPressService.getCreateOrderData().then(
			          function(response) { 
			        	  var respData = response.data;
			        	  srAngCntxt.scope.pressList = respData.pressList;
			  			  srAngCntxt.scope.productList = respData.productList;
			  			  load_pressProductDetDTB();
			          },
			          function(errorPayload) {
			        	  load_pressProductDetDTB();
			          }
			);
		}
};


