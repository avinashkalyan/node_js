$(".nav-tabs li.active").removeClass("active");
$(".nav-tabs li:nth-child(2)").addClass("active");