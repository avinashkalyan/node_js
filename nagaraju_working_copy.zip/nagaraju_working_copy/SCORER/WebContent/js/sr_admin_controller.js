var srAngCntxt={};
var srAdminAddProductJS = {
		init:function(){
			//initialization
			srAngCntxt.scope.userInput = {};
		}
};