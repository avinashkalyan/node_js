var sr_app=angular.module('sr_app', ['ui.bootstrap','ngRoute']);
sr_app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
    	/*Press flow urls*/
    	redirectTo: '/sr_press_home'
    }).when("/sr_press_home", {
        templateUrl : "sr_press_order_list_all.html"
    }).when("/sr_press_order_create", {
        templateUrl : "sr_press_order_create.html"
    }).when("/sr_admin_home", {
    	/*admin flow urls*/
        templateUrl : "sr_admin_home.html"
    }).when("/sr_admin_add_dealer", {
        templateUrl : "sr_admin_add_dealer.html"
    }).when("/sr_admin_add_press", {
        templateUrl : "sr_admin_add_press.html"
    }).when("/sr_admin_add_product", {
        templateUrl : "sr_admin_add_product.html"
    }).when("/sr_customer_home", {
    	/*customer flow urls*/
        templateUrl : "sr_customer_order_list_all.html"
    }).otherwise({
        templateUrl : "error.html"
    });
});



/*press services & controllers controllers*/
sr_app.service('srPressService', function(){
	return {
		getAllOrders:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {allOrders:pressStaticData.allOrders, dealerList:dbStaticData.dealerList}
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getCreateOrderData:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {pressList:dbStaticData.pressList,productList:dbStaticData.productList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		}
	};
});
/*all orders*/
sr_app.controller('srPressOrderListAllController',
				["$scope", '$http','$q','srPressService',
                 function($scope, $http, $q, srPressService){
	srAngCntxt = {scope:$scope, http:$http, srPressService:srPressService, q:$q};
	srPressOrderListAllControllerJS.init();
}]);

sr_app.controller('srPressOrderCreate',
		["$scope", '$http','$q','srPressService',
         function($scope, $http, $q, srPressService){
srAngCntxt = {scope:$scope, http:$http, srPressService:srPressService, q:$q};
srPressOrderCreateJS.init();
}]);

/*admin services and controllers*/
sr_app.controller('srAdminAddProduct',
		["$scope", '$http','$q',
         function($scope, $http, $q){
srAngCntxt = {scope:$scope, http:$http, q:$q};
srAdminAddProductJS.init();
}]);




