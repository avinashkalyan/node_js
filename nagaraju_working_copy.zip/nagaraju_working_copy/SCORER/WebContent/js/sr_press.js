var sr_press_data_tables = {};
$(".nav-tabs li.active").removeClass("active");
$(".nav-tabs li:nth-child(1)").addClass("active");
/*all orders data-table*/
function load_PressAllOrdersDTB(orderList){
	var pressAllOrdersDTB = $('#pressAllOrdersDTB').DataTable({
		"aaData":orderList,
		"bPaginate": true,
		"bFilter": true,
		"bInfo" : true,
		"columns": [
					{
						"className":      'details-control',
						"orderable":      false,
						"data":           null,
						"defaultContent": '<span class="dt_span glyphicon glyphicon-plus"></span>',
						"title":""
					},
					{ "title":"Order Date", "data": "orderDate" },
					{ "title":"Order Number", "data": "orderNum" },
					{ "title":"Press Name", "data": "pressDetails.pressName" },
					{ "title":"Mobile", "data": "pressDetails.pressMobile" },
					{ "title":"City", "data": "pressDetails.city" },
					{ "title":"Contact Person", "data": "pressDetails.contactPerson" },
					{ "title":"Order Status", "data": "orderStatus" },
					{ "title":"Order Amount", "data": "orderAmount" },
					{ "title":"Amount Paid", "data": "amountPaid" },
					{ "title":"Amount Due", "data": function(colVal){
														return colVal.orderAmount - colVal.amountPaid; 
									            	} 
					}
		],
		"order": [[1, 'asc']],
		"footerCallback": function ( row, data, start, end, display ){
			var api = this.api();
			renderFooterTotal(row, data, start, end, display, api, 8);
			renderFooterTotal(row, data, start, end, display, api, 9);
			renderFooterTotal(row, data, start, end, display, api, 10);
		}
	});
	sr_press_data_tables.pressAllOrdersDTB = pressAllOrdersDTB;
	/*press order table events*/
	$('#pressAllOrdersDTB tbody').on('click', 'td.details-control', function () {
		var tr = $(this).closest('tr', '#pressAllOrdersDTB tbody');
		var row = pressAllOrdersDTB.row(this);
		$(".dt_span",this).toggleClass("glyphicon-minus")
		if ( row.child.isShown() ) {
			row.child.hide();
			tr.removeClass('shown');
		} else {
			load_PressAllOrdersDTB_SubData(row);
			tr.addClass('shown');
		}
	} );
 }

function renderFooterTotal(row, data, start, end, display, api, colIndex){
	 //total
	var total = api.column( colIndex ).data().reduce( function (a, b) {
            	return sr_utils.intVal(a) +sr_utils.intVal(b); }, 0 );
    //current page total
	var pageTotal = api.column( colIndex, { page: 'current'} ).data().reduce( function (a, b) {
        		return sr_utils.intVal(a) + sr_utils.intVal(b); }, 0 );
    //update footer
	//$( api.column( colIndex ).footer() ).html(pageTotal+'<span class="tot_amt_sep"> / </span>'+total);
	$( api.column( colIndex ).footer() ).html(total);
}

function load_PressAllOrdersDTB_SubData(row){
	var orderDetails = row.data();
	srAngCntxt.scope.selectedOrderDetails = orderDetails;
	var ordSecId = 'ord_det_section_'+orderDetails.orderNum;
	var dynHTML = '<div id="'+ordSecId+'" class="ord_det_section">';
	dynHTML = dynHTML+$("#pressOrderDetDiv").html()+'</div>';
	row.child(dynHTML).show();
	
	/*order product details*/
	var ordPrdDetTabId = 'pressOrdProdDetDTB_'+orderDetails.orderNum;
	$(".pressOrdProdDetDTB","#"+ordSecId).attr("id",ordPrdDetTabId);
	var pressOrdProdDetDTB = $("#"+ordPrdDetTabId).DataTable( {
		"aaData":orderDetails.productDetails,
		"bPaginate": false,
		"bFilter": false,
		"bInfo" : false,
		"columns": [
			            {  "title":"Product",
			            	"data": "productName"
			            },
			            { "title":"Quantity", "data": "quantity" },
			            { "title":"Rate", "data": "rate" },
			            {  "title":"Amount",
			            	"data": function(colVal){
			            		return colVal.quantity*colVal.rate; 
			            	}
			            }
		            ],
		"order": [[1, 'asc']]
	});
	sr_press_data_tables.ordPrdDetTabId=pressOrdProdDetDTB;
	
	/*delivery details*/
	var deliv_tableId = 'pressOrdProdDeliveryDTB_'+orderDetails.orderNum;
	$(".pressOrdProdDeliveryDTB","#"+ordSecId).attr("id",deliv_tableId);
	var deliveryDetDTB = $("#"+deliv_tableId).DataTable({
		"aaData":orderDetails.deliveryDetails,
		"bPaginate": false,
		"bFilter": false,
		"bInfo" : false,
		"columns": [
			            { "title":"Delivery Date", "data": "deliveryDate" },
			            {  "title":"Product Details",
			            	"data": function(colVal){
								var val=""; 
								$.each(colVal.productDetails, function( index, value) {
								  val=val+value.productName+" - "+value.productLanguage+" ( "+value.quantity+" )<br/> ";
								});
								return val; 
			            	}
			            },
			            { "title":"Delivered To", "data": "deliverTo" }
		            ],
		"order": [[1, 'asc']]
	});
	sr_press_data_tables.deliv_tableId=deliveryDetDTB;
	
	/*payment details*/
	var payment_tableId = 'pressOrdPaymentDetDTB_'+orderDetails.orderNum;
	$(".pressOrdPaymentDetDTB","#"+ordSecId).attr("id",payment_tableId);
	var paymentDetDTB = $("#"+payment_tableId).DataTable({
		"aaData":orderDetails.paymentDetails,
		"bPaginate": false,
		"bFilter": false,
		"bInfo" : false,
		"columns": [
			            { "title":"Paid Date", "data": "paymentDate" },
			            { "title":"Amount", "data": "amount" },
			            { "title":"Paid To", "data": "paymentRecivedPerson" },
			            { "title":"Comments", "data": "comments" }
		            ],
		"order": [[1, 'asc']]
	});
	sr_press_data_tables.payment_tableId=paymentDetDTB;
}

function load_inputDeliveryProductDetDTB(){
	 if(sr_press_data_tables.inputDeliveryProductDetDTB == undefined){
			var inputDeliveryProductDetDTB = $('#inputDeliveryProductDetDTB').DataTable({
				"aaData":srAngCntxt.scope.selectedOrderDetails.productDetails,
				"bPaginate": false,
				"bFilter": false,
				"bInfo" : false,
				"columns": [
							{  "title":"Product Details",
				            	"data": function(colVal){
									return colVal.productName; 
				            	}
				            },
				            {   "title":"Quantity", 
				            	"orderable":      false,
								"data":           null,
								"defaultContent":'<input type="text">'
				            }
				],
				"order": [[1, 'asc']]
			});
			sr_press_data_tables.inputDeliveryProductDetDTB=inputDeliveryProductDetDTB;
	}else{
		sr_press_data_tables.inputDeliveryProductDetDTB.reload();
	}
}
function load_pressProductDetDTB(){
	/*selected product detaions*/
	/*available Product details*/
	if(sr_press_data_tables.pressCreateOrdProductDetDTB == undefined){
		var pressCreateOrdProductDetDTB = $('#pressCreateOrdProductDetDTB').DataTable({
			"aaData":srAngCntxt.scope.productList,
			"bPaginate": false,
			"bFilter": true,
			"bInfo" : false,
			"columns": [
			            {   
							"orderable":      false,
							"data":           null,
							"defaultContent": '<div class="checkbox"><label><input type="checkbox" value=""></label></div>',
							"title":"" 
						},
						{ "title":"Product Name", "data": "productName" },
			            { "title":"Author", "data": "author" }
			],
			"order": [[1, 'asc']]
		});
		sr_press_data_tables.pressCreateOrdProductDetDTB=pressCreateOrdProductDetDTB;
	}
 }

function populateSelectedData(){
	 $("#selectedProductDetDTB").removeClass("hide");
	 if(sr_press_data_tables.selectedProductDetDTB == undefined){
			var selectedProductDetDTB = $('#selectedProductDetDTB').DataTable({
				"bPaginate": false,
				"bFilter": false,
				"bInfo" : false,
				"order": [[1, 'asc']]
			});
			sr_press_data_tables.selectedProductDetDTB=selectedProductDetDTB;
	}
}
function updateTotal(){
	var total = 0;
    var obj = srAngCntxt.scope.createOrderInput.selectedProductListInput;
    $.each(obj, function (i, v) {
    	total = total+(sr_utils.intVal(v.quantity)*sr_utils.intVal(v.rate));
    });
    srAngCntxt.scope.createOrderInput.totalAmount = total;
}



