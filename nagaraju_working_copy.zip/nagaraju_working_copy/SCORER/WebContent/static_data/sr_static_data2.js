/** Admin Data**/
var staticUser = "admin";
var staticPW = "admin2017";
var dbStaticData = {
					productList:[{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu", "author":"Sasidhar"}, {"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu", "author":"Sasidhar"}, {"prodID":"SRPRD0001003","productName":"Chemistry","productLanguage":"English", "author":"Sasidhar"}, {"prodID":"SRPRD0001004","productName":"Biology","productLanguage":"English", "author":"Sasidhar"},{"prodID":"SRPRD0001005","productName":"Zoology","productLanguage":"English", "author":"Sasidhar"},{"prodID":"SRPRD0001006","productName":"Mathematics","productLanguage":"English", "author":"Sasidhar"}],
					pressList:["Amaravathi-1","Amaravathi-2","Amaravathi-3","Amaravathi-4","Amaravathi-5","Amaravathi-6","Pivotal-1","Pivotal-2","Pivotal-3","Pivotal-4","Pivotal-5","Pivotal-6","Rathika-1","Rathika-2","Rathika-3","Rathika-4","Rathika-5","Rathika-6"],
					dealerList:["Sasidhar","Ramarao","Srinu","Sathya"],
					languageList:["Telugu","English"]
			};


/** Press Flow Data**/
var pressStaticData = {allOrders:[
	                              	{"orderDate": "10-Nov-2017 10:15 am","orderNum": "ORD00001001","orderAmount": "4200","amountPaid": "1500", "orderStatus": "PENDING",
									"productDetails":[{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu", "quantity":"200", "rate":"15"}, {"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu", "quantity":"30", "rate":"20"},{"prodID":"SRPRD0001003","productName":"Chemistry","productLanguage":"English", "quantity":"10", "rate":"60"}],
									"pressDetails":{"pressID":"SRPRESS0000501","pressName": "Sri Ram Printers","pressMobile": "9945678915, 8987544545, 454555689","city": "Amaravathi","contactPerson": "Srinivas"},
									"deliveryDetails":[{"deliveryDate": "11-Nov-2017 10:15 am", "productDetails":[{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu", "quantity":"100"}, {"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu", "quantity":"10"},{"prodID":"SRPRD0001003","productName":"Chemistry","productLanguage":"English", "quantity":"5"}] }, {"deliveryDate": "12-Nov-2017 10:15 am","deliveryId":"order12", "productDetails":[{"productName":"Physics","productLanguage":"Telugu", "quantity":"40"}, {"productName":"Chemistry","productLanguage":"Telugu", "quantity":"10"},{"productName":"Chemistry","productLanguage":"English", "quantity":"60"}] }], 
									"paymentDetails":[{"paymentDate": "12-Nov-2017 10:15 am", "amount":"1000", "paymentRecivedPerson":"Srinivas", "comments":"Paid to sbi account# SBIAC56510256"}, {"paymentDate": "13-Nov-2017 10:15 am", "amount":"500", "paymentRecivedPerson":"Srinivas", "comments":"paid to icici account# ICICIAC565105878"}]}
									
									,{"orderDate": "10-Nov-2017 10:15 am","orderNum": "ORD00001002","orderAmount": "19000","amountPaid": "12000", "orderStatus": "PENDING",
									"productDetails":[{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu", "quantity":"1900", "rate":"20"}, {"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu", "quantity":"100", "rate":"10"}],
									"pressDetails":{"pressID":"SRPRESS0000501","pressName": "Sai Ram Printers","pressMobile": "22222222, 00004445558, 999987755546","city": "hyderabad","contactPerson": "Avinash"},
									"deliveryDetails":[{"deliveryDate": "11-Nov-2017 10:15 am", "productDetails":[{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu", "quantity":"100"}, {"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu", "quantity":"10"}] }, {"deliveryDate": "12-Nov-2017 10:15 am","deliveryId":"order12", "productDetails":[{"productName":"Physics","productLanguage":"Telugu", "quantity":"40"}, {"productName":"Chemistry","productLanguage":"Telugu", "quantity":"10"},{"productName":"Chemistry","productLanguage":"English", "quantity":"60"}] }], 
									"paymentDetails":[{"paymentDate": "12-Nov-2017 10:15 am", "amount":"1000", "paymentRecivedPerson":"Srinivas", "comments":"Paid to sbi account# SBIAC56510256"}, {"paymentDate": "13-Nov-2017 10:15 am", "amount":"500", "paymentRecivedPerson":"Srinivas", "comments":"paid to icici account# ICICIAC565105878"}]}
									
	                              ]};
var staticSelectedProductList = [{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu"}, {"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu"},{"prodID":"SRPRD0001003","productName":"Chemistry","productLanguage":"English"}];

var staticselectedProductListInput ={"SRPRD0001001":{"prodID":"SRPRD0001001","productName":"Physics","productLanguage":"Telugu", "quantity":"0", "rate":"0"},"SRPRD0001002":{"prodID":"SRPRD0001002","productName":"Chemistry","productLanguage":"Telugu", "quantity":"0", "rate":"0"},"SRPRD0001003":{"prodID":"SRPRD0001003","productName":"Chemistry","productLanguage":"English", "quantity":"0", "rate":"0"}};
/** Customer Flow Data**/

