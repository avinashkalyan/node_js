function validate()
{
   if( document.PressRegistration.name.value == "" )
   {
     alert( "Please provide your Press Name!" );
     document.PressRegistration.name.focus() ;
     return false;
   }

   if( document.PressRegistration.cityname.value == "" )
   {
     alert( "Please provide your City!" );
     document.PressRegistration.cityname.focus() ;
     return false;
   }
   if( document.PressRegistration.districtname.value == "" )
   {
     alert( "Please provide your Select District!" );
     document.PressRegistration.districtname.focus() ;
     return false;
   }
   if( document.PressRegistration.statename.value == "" )
   {
     alert( "Please provide your Select State!" );
     document.PressRegistration.statename.focus() ;
     return false;
   }
   if( document.PressRegistration.pincode.value == "" ||
           isNaN( document.PressRegistration.pincode.value) ||
           document.PressRegistration.pincode.value.length != 6 )
   {
     alert( "Please provide a pincode in the format ######." );
     document.PressRegistration.pincode.focus() ;
     return false;
   }
 var email = document.PressRegistration.emailid.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
 if (email == "" || atpos < 1 || ( dotpos - atpos < 2 ))
 {
     alert("Please enter correct email ID")
     document.PressRegistration.emailid.focus() ;
     return false;
 }

  if( document.PressRegistration.mobileno.value == "" ||
           isNaN( document.PressRegistration.mobileno.value) ||
           document.PressRegistration.mobileno.value.length != 10 )
   {
     alert( "Please provide a Mobile No in the format 123." );
     document.PressRegistration.mobileno.focus() ;
     return false;
   }
   return( true );
}
