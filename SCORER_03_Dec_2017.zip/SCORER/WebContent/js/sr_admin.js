$(".nav-tabs li.active").removeClass("active");
$(".nav-tabs li:nth-child(3)").addClass("active");
var sr_admin_data_tables = {};
function load_adminAllInventoryDTB(inventoryList){
	 if(sr_admin_data_tables.adminAllInventoryDTB == undefined){
			var adminAllInventoryDTB = $('#adminAllInventoryDTB').DataTable({
				"aaData":inventoryList,
				"bPaginate": false,
				"bFilter": true,
				"bInfo" : false,
				"columns": [
						{ "title":"Product Name", "data": "productName" },
			            { "title":"Author", "data": "author" },
						{ "title":"Received", "data": "receivedQuantiry" },
						{ "title":"Delivered", "data": "deliveredQuantity" },
						{  "title":"Available",
				            	"data": function(colVal){
									return sr_utils.intVal(colVal.receivedQuantiry) - sr_utils.intVal(colVal.deliveredQuantity); 
				            	}
				        }
				],
				"order": [[1, 'asc']]
			});
			sr_admin_data_tables.adminAllInventoryDTB=adminAllInventoryDTB;
	}else{
		sr_admin_data_tables.adminAllInventoryDTB.reload();
	}
}
function load_adminPressListDTB(pressList){
	 if(sr_admin_data_tables.adminPressListDTB == undefined){
			var adminPressListDTB = $('#adminPressListDTB').DataTable({
				"aaData":pressList,
				"bPaginate": false,
				"bFilter": true,
				"bInfo" : false,
				"columns": [
						{ "title":"Press Name", "data": "pressName" },
						{ "title":"Mobile", "data": "pressMobile" },
						{ "title":"City", "data": "city" },
						{ "title":"Contact Person", "data": "contactPerson" },
						{
							"className":      'editPressDet',
							"orderable":      false,
							"data":           null,
							"defaultContent": '<a href="#!sr_admin_edit_press"><span class="dt_span glyphicon glyphicon-pencil"></span></a>',
							"title":""
						}
				],
				"order": [[1, 'asc']]
			});
			sr_admin_data_tables.adminPressListDTB=adminPressListDTB;
	}else{
		sr_admin_data_tables.adminPressListDTB.reload();
	}
}
function load_adminCustListDTB(custList){
	 if(sr_admin_data_tables.adminCustListDTB == undefined){
			var adminCustListDTB = $('#adminCustListDTB').DataTable({
				"aaData":custList,
				"bPaginate": false,
				"bFilter": true,
				"bInfo" : false,
				"columns": [
						{ "title":"Customer", "data": "custName" },
						{ "title":"Contact Person", "data": "contactPerson" },
						{ "title":"Mobiule", "data": "custMobile" },
						{ "title":"City", "data": "city" },
						{
							"className":      'editCustDet',
							"orderable":      false,
							"data":           null,
							"defaultContent": '<a href="#!sr_admin_edit_cust"><span class="dt_span glyphicon glyphicon-pencil"></span></a>',
							"title":""
						}
				],
				"order": [[1, 'asc']]
			});
			sr_admin_data_tables.adminCustListDTB=adminCustListDTB;
	}else{
		sr_admin_data_tables.adminCustListDTB.reload();
	}
}
function load_adminDealerListDTB(dealerList){
	 if(sr_admin_data_tables.adminDealerListDTB == undefined){
			var adminDealerListDTB = $('#adminDealerListDTB').DataTable({
				"aaData":dealerList,
				"bPaginate": false,
				"bFilter": true,
				"bInfo" : false,
				"columns": [
						{ "title":"Dealer Name", "data": "dealerName" },
						{ "title":"Mobile", "data": "dealerMobile" },
						{
							"className":      'editDealerDet',
							"orderable":      false,
							"data":           null,
							"defaultContent": '<a href="#!sr_admin_edit_dealer"><span class="dt_span glyphicon glyphicon-pencil"></span></a>',
							"title":""
						}
				],
				"order": [[1, 'asc']]
			});
			sr_admin_data_tables.adminDealerListDTB=adminDealerListDTB;
	}else{
		sr_admin_data_tables.adminDealerListDTB.reload();
	}
}
function load_adminProductListDTB(productList){
	 if(sr_admin_data_tables.adminProductListDTB == undefined){
			var adminProductListDTB = $('#adminProductListDTB').DataTable({
				"aaData":productList,
				"bPaginate": false,
				"bFilter": true,
				"bInfo" : false,
				"columns": [
						{ "title":"Product Name", "data": "productName" },
						{ "title":"Author", "data": "author" },
						{
							"className":      'editProductDet',
							"orderable":      false,
							"data":           null,
							"defaultContent": '<a href="#!sr_admin_edit_product"><span class="dt_span glyphicon glyphicon-pencil"></span></a>',
							"title":""
						}
				],
				"order": [[1, 'asc']]
			});
			sr_admin_data_tables.adminProductListDTB=adminProductListDTB;
	}else{
		sr_admin_data_tables.adminProductListDTB.reload();
	}
}
function load_adminMiscExpnsListDTB(expenditureList){
	 if(sr_admin_data_tables.adminMiscExpnsListDTB == undefined){
			var adminMiscExpnsListDTB = $('#adminMiscExpnsListDTB').DataTable({
				"aaData":expenditureList,
				"bPaginate": false,
				"bFilter": true,
				"bInfo" : false,
				"columns": [
						{ "title":"Transaction Date", "data": "transactionDate" },
						{ "title":"Dealer Name", "data": "dealer" },
						{ "title":"Amount", "data": "amount" },
						{ "title":"Comments", "data": "comments" }
				],
				"order": [[1, 'asc']]
			});
			sr_admin_data_tables.adminMiscExpnsListDTB=adminMiscExpnsListDTB;
	}else{
		sr_admin_data_tables.adminMiscExpnsListDTB.reload();
	}
}
