var srAngCntxt={};
var srAdminAddProductJS = {
		init:function(){
			//initialization
			srAngCntxt.scope.userInput = {};
		}
};

var srAdminAddExpensesJS = {
		init:function(){
			//initialization
			srAngCntxt.scope.createExpnsInput = {};
			srAngCntxt.srAdminService.getDealerList().then(
			          function(response) { 
			        	  srAngCntxt.scope.dealerList = response.data.dealerList;
			          },
			          function(errorPayload) {
			        	  srAngCntxt.scope.dealerList = [];
			          }
			);
		}
};
var srAdminInventoryJS = {
		init:function(){
			//initialization
			srAngCntxt.srAdminService.getInventoryDet().then(
			          function(response) { 
			        	  load_adminAllInventoryDTB(response.data.inventoryList);
			          },
			          function(errorPayload) {
			        	  load_adminAllInventoryDTB([]);
			          }
			);
		}
};
var srAdminPressListJS = {
		init:function(){
			//initialization
			srAngCntxt.srAdminService.getPressListFullDet().then(
			          function(response) { 
			        	  load_adminPressListDTB(response.data.pressList);
			          },
			          function(errorPayload) {
			        	  load_adminPressListDTB([]);
			          }
			);
		}
};
var srAdminCustListJS = {
		init:function(){
			//initialization
			srAngCntxt.srAdminService.getCustListFullDet().then(
			          function(response) { 
			        	  load_adminCustListDTB(response.data.custList);
			          },
			          function(errorPayload) {
			        	  load_adminCustListDTB([]);
			          }
			);
		}
};
var srAdminDealerListJS = {
		init:function(){
			//initialization
			srAngCntxt.srAdminService.getDealerListFullDet().then(
			          function(response) { 
			        	  load_adminDealerListDTB(response.data.dealerList);
			          },
			          function(errorPayload) {
			        	  load_adminDealerListDTB([]);
			          }
			);
		}
};
var srAdminProductListJS = {
		init:function(){
			//initialization
			srAngCntxt.srAdminService.getProductListFullDet().then(
			          function(response) { 
			        	  load_adminProductListDTB(response.data.productList);
			          },
			          function(errorPayload) {
			        	  load_adminProductListDTB([]);
			          }
			);
		}
};
var srAdminMiscExpnsListJS = {
		init:function(){
			//initialization
			srAngCntxt.srAdminService.getExpenditureListFullDet().then(
			          function(response) { 
			        	  load_adminMiscExpnsListDTB(response.data.expenditureList);
			          },
			          function(errorPayload) {
			        	  load_adminMiscExpnsListDTB([]);
			          }
			);
		}
};



