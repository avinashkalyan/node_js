var sr_utils = {
		intVal:function ( i ) {
            return typeof i === 'string' ?
                i.replace(/[\$,]/g, '')*1 :
                typeof i === 'number' ?
                    i : 0;
        },
		printPage:function() {
			var innerContents = $("#sr_tab_content_div").html();
			var popupWinindow = window.open('', '_blank', 'scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
			popupWinindow.document.open();
			popupWinindow.document.write('<html><head>');
			popupWinindow.document.write('<title>SCORER-HOME</title><meta charset="UTF-8"><meta http-equiv="Content-Type" content="text/html;" /><meta name="viewport" content="width=device-width, initial-scale=1">');
			popupWinindow.document.write('<link rel="stylesheet" href="../static_frmwrks/bt/css/bootstrap.min.css"><link rel="stylesheet" href="../static_frmwrks/dt/css/dataTables.bootstrap.min.css"><link rel="stylesheet" href="../css/print.css">');
			popupWinindow.document.write('</head><body onload="window.print()">' + innerContents + '</html>');
			popupWinindow.document.close();
      }
};

function renderFooterTotal(row, data, start, end, display, api, colIndex){
	 //total
	var total = api.column( colIndex ).data().reduce( function (a, b) {
            	return sr_utils.intVal(a) +sr_utils.intVal(b); }, 0 );
    //current page total
	var pageTotal = api.column( colIndex, { page: 'current'} ).data().reduce( function (a, b) {
        		return sr_utils.intVal(a) + sr_utils.intVal(b); }, 0 );
    //update footer
	//$( api.column( colIndex ).footer() ).html(pageTotal+'<span class="tot_amt_sep"> / </span>'+total);
	$( api.column( colIndex ).footer() ).html(pageTotal);
}