$(".nav-tabs li.active").removeClass("active");
$(".nav-tabs li:nth-child(2)").addClass("active");
var sr_cust_data_tables = {};
/*all orders data-table*/
function load_CustAllOrdersDTB(orderList){
	var custAllOrdersDTB = $('#custAllOrdersDTB').DataTable({
		"aaData":orderList,
		"bPaginate": false,
		"bFilter": true,
		"bInfo" : true,
		"columns": [
					{
						"className":      'details-control',
						"orderable":      false,
						"data":           null,
						"defaultContent": '<span class="dt_span glyphicon glyphicon-plus"></span>',
						"title":""
					},
					{ "title":"Order Date", "data": "orderDate" },
					{ "title":"Order Number", "data": "orderNum" },
					{ "title":"Customer", "data": "custDetails.custName" },
					{ "title":"Contact Person", "data": "custDetails.contactPerson" },
					{ "title":"Mobile", "data": "custDetails.custMobile"},
					{ "title":"City", "data": "custDetails.city" },
					{ "title":"Dealer Name", "data": "custDetails.dealerName" },
					{ "title":"Order Status", "data": "orderStatus" },
					{ "title":"Order Amount", "data": "orderAmount" },
					{ "title":"Amount Received", "data": "amountPaid" },
					{ "title":"Amount Due", "data": function(colVal){
														return colVal.orderAmount - colVal.amountPaid; 
									            	} 
					}
		],
		"order": [[1, 'asc']],
		"footerCallback": function ( row, data, start, end, display ){
			var api = this.api();
			renderFooterTotal(row, data, start, end, display, api, 9);
			renderFooterTotal(row, data, start, end, display, api, 10);
			renderFooterTotal(row, data, start, end, display, api, 11);
		},
		//"lengthMenu": [[-1, 10, 50, 100], ["All", 10, 50, 100]]
		//"lengthMenu": [[-1], ["All"]]
	});
	sr_cust_data_tables.custAllOrdersDTB = custAllOrdersDTB;
	/*customer order table events*/
	$('#custAllOrdersDTB tbody').on('click', 'td.details-control', function () {
		var tr = $(this).closest('tr', '#custAllOrdersDTB tbody');
		var row = custAllOrdersDTB.row(this);
		$(".dt_span",this).toggleClass("glyphicon-minus")
		if ( row.child.isShown() ) {
			row.child.hide();
			tr.removeClass('shown');
		} else {
			load_CustAllOrdersDTB_SubData(row);
			tr.addClass('shown');
		}
	} );
 }
function load_CustAllOrdersDTB_SubData(row){
	var orderDetails = row.data();
	//update order and payment status
	orderDetails.paymentStatus = "CLOSED";
	orderDetails.deliveryStatus = "CLOSED";
	if(orderDetails.orderStatus == "ORDER_PENDING"){
		orderDetails.deliveryStatus = "PENDING";
	}
	if(orderDetails.amountPaid < orderDetails.orderAmount){
		orderDetails.paymentStatus = "PENDING";
	}
	srAngCntxt.scope.selectedOrderDetails = orderDetails;
	srAngCntxt.scope.$apply();
	var ordSecId = 'ord_det_section_'+orderDetails.orderNum;
	var dynHTML = '<div id="'+ordSecId+'" class="ord_det_section">';
	dynHTML = dynHTML+$("#custOrderDetDiv").html()+'</div>';
	row.child(dynHTML).show();
	
	/*order product details*/
	var ordPrdDetTabId = 'custOrdProdDetDTB_'+orderDetails.orderNum;
	$(".custOrdProdDetDTB","#"+ordSecId).attr("id",ordPrdDetTabId);
	var custOrdProdDetDTB = $("#"+ordPrdDetTabId).DataTable( {
		"aaData":orderDetails.productDetails,
		"bPaginate": false,
		"bFilter": false,
		"bInfo" : false,
		"columns": [
			            {  "title":"Product",
			            	"data": "productName"
			            },
			            { "title":"Quantity", "data": "quantity" },
			            { "title":"Rate", "data": "rate" },
			            {  "title":"Amount",
			            	"data": function(colVal){
			            		return colVal.quantity*colVal.rate; 
			            	}
			            },
						{ "title":"Delivery Pending", "data": "deliveryPending" }
		            ],
		"order": [[1, 'asc']]
	});
	sr_cust_data_tables.ordPrdDetTabId=custOrdProdDetDTB;
	
	/*delivery details*/
	var deliv_tableId = 'custOrdProdDeliveryDTB_'+orderDetails.orderNum;
	$(".custOrdProdDeliveryDTB","#"+ordSecId).attr("id",deliv_tableId);
	var deliveryDetDTB = $("#"+deliv_tableId).DataTable({
		"aaData":orderDetails.deliveryDetails,
		"bPaginate": false,
		"bFilter": false,
		"bInfo" : false,
		"columns": [
			            { "title":"Delivery Date", "data": "deliveryDate" },
			            {  "title":"Product Details",
			            	"data": function(colVal){
								var val=""; 
								$.each(colVal.productDetails, function( index, value) {
								  val=val+value.productName+" - "+value.productLanguage+" ( "+value.quantity+" )<br/> ";
								});
								return val; 
			            	}
			            },
			            { "title":"Delivered To", "data": "deliverTo" }
		            ],
		"order": [[1, 'asc']]
	});
	sr_cust_data_tables.deliv_tableId=deliveryDetDTB;
	
	/*payment details*/
	var payment_tableId = 'custOrdPaymentDetDTB_'+orderDetails.orderNum;
	$(".custOrdPaymentDetDTB","#"+ordSecId).attr("id",payment_tableId);
	var paymentDetDTB = $("#"+payment_tableId).DataTable({
		"aaData":orderDetails.paymentDetails,
		"bPaginate": false,
		"bFilter": false,
		"bInfo" : false,
		"columns": [
			            { "title":"Paid Date", "data": "paymentDate" },
			            { "title":"Amount", "data": "amount" },
			            { "title":"Paid To", "data": "paymentRecivedPerson" },
			            { "title":"Comments", "data": "comments" }
		            ],
		"order": [[1, 'asc']]
	});
	sr_cust_data_tables.payment_tableId=paymentDetDTB;
}

function load_inputDeliveryProductDetDTB(){
	 if(sr_cust_data_tables.inputDeliveryProductDetDTB == undefined){
			var inputDeliveryProductDetDTB = $('#inputDeliveryProductDetDTB').DataTable({
				"aaData":srAngCntxt.scope.selectedOrderDetails.productDetails,
				"bPaginate": false,
				"bFilter": false,
				"bInfo" : false,
				"columns": [
							{  "title":"Product Details",
				            	"data": function(colVal){
									return colVal.productName; 
				            	}
				            },
				            {   "title":"Quantity", 
				            	"orderable":      false,
								"data":           null,
								"defaultContent":'<input type="text">'
				            }
				],
				"order": [[1, 'asc']]
			});
			sr_cust_data_tables.inputDeliveryProductDetDTB=inputDeliveryProductDetDTB;
	}else{
		sr_cust_data_tables.inputDeliveryProductDetDTB.reload();
	}
}
function load_custProductDetDTB(){
	/*selected product detaions*/
	/*available Product details*/
	if(sr_cust_data_tables.custCreateOrdProductDetDTB == undefined){
		var custCreateOrdProductDetDTB = $('#custCreateOrdProductDetDTB').DataTable({
			"aaData":srAngCntxt.scope.productList,
			"bPaginate": false,
			"bFilter": true,
			"bInfo" : false,
			"columns": [
			            {   
							"orderable":      false,
							"data":           null,
							"defaultContent": '<div class="checkbox"><label><input type="checkbox" class="selecProdCheckBox" value=""></label></div>',
							"title":"" 
						},
						{ "title":"Product Name", "data": "productName" },
			            { "title":"Author", "data": "author" }
			],
			"order": [[1, 'asc']]
		});
		sr_cust_data_tables.custCreateOrdProductDetDTB=custCreateOrdProductDetDTB;
	}
 }

function populateSelectedData(){
	 //get selected productlist
	 var selectedProductList = [];
	 $("#custCreateOrdProductDetDTB tbody .selecProdCheckBox:checked").each(function(){
		var obj = sr_cust_data_tables.custCreateOrdProductDetDTB.row($(this).parents('tr')).data();
		if(obj.quantity == undefined){
			obj.quantity = 0;
		}
		if(obj.rate == undefined){
			obj.rate = 0;
		}
		selectedProductList.push(obj);
	 });
	 srAngCntxt.scope.createOrderInput.selectedProductList = selectedProductList;
	 srAngCntxt.scope.$apply();
	 //update screen status
	 $("#selectedProductDetDTB").removeClass("hide");
	 if(sr_cust_data_tables.selectedProductDetDTB == undefined){
			var selectedProductDetDTB = $('#selectedProductDetDTB').DataTable({
				"bPaginate": false,
				"bFilter": false,
				"bInfo" : false,
				"order": [[1, 'asc']]
			});
			sr_cust_data_tables.selectedProductDetDTB=selectedProductDetDTB;
	 }
	 calculateSumCrtOrd();
}
function updateTotal(){
	var total = 0;
    var obj = srAngCntxt.scope.createOrderInput.selectedProductList;
    $.each(obj, function (i, v) {
    	total = total+(sr_utils.intVal(v.quantity)*sr_utils.intVal(v.rate));
    });
    srAngCntxt.scope.createOrderInput.totalAmount = total;
	srAngCntxt.scope.$apply();
}



