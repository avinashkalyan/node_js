var sr_app=angular.module('sr_app', ['ui.bootstrap','ngRoute']);
sr_app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
    	/*Press flow urls*/
    	redirectTo: '/sr_press_home' 
    }).when("/sr_press_home", {
        templateUrl : "sr_press_order_list_all.html"
    }).when("/sr_press_order_create", {
        templateUrl : "sr_press_order_create.html"
    }).when("/sr_cust_home", {
    	/*customer flow urls*/
        templateUrl : "sr_customer_order_list_all.html"
    }).when("/sr_cust_order_create", {
        templateUrl : "sr_cust_order_create.html"
    }).when("/sr_admin_home", {
    	/*admin flow urls*/
        templateUrl : "sr_admin_home.html"
    }).when("/sr_admin_add_dealer", {
        templateUrl : "sr_admin_add_dealer.html"
    }).when("/sr_admin_add_press", {
        templateUrl : "sr_admin_add_press.html"
    }).when("/sr_admin_add_product", {
        templateUrl : "sr_admin_add_product.html"
    }).when("/sr_admin_add_cust", {
        templateUrl : "sr_admin_add_cust.html"
    }).when("/sr_admin_add_misc_exp", {
        templateUrl : "sr_admin_add_misc_expns.html"
    }).when("/sr_admin_inventory", {
        templateUrl : "sr_admin_inventory.html"
    }).when("/sr_admin_press_list", {
        templateUrl : "sr_admin_press_list.html"
    }).when("/sr_admin_password_change", {
        templateUrl : "sr_admin_password_change.html"
    }).when("/sr_admin_edit_press", {
        templateUrl : "sr_admin_edit_press.html"
    }).when("/sr_admin_edit_cust", {
        templateUrl : "sr_admin_edit_cust.html"
    }).when("/sr_admin_cust_list", {
        templateUrl : "sr_admin_cust_list.html"
    }).when("/sr_admin_dealer_list", {
        templateUrl : "sr_admin_dealer_list.html"
    }).when("/sr_admin_edit_dealer", {
        templateUrl : "sr_admin_edit_dealer.html"
    }).when("/sr_admin_edit_product", {
        templateUrl : "sr_admin_edit_product.html"
    }).when("/sr_admin_product_list", {
        templateUrl : "sr_admin_product_list.html"
    }).when("/sr_admin_mis_expnses_list", {
        templateUrl : "sr_admin_mis_expnses_list.html"
    }).otherwise({
        templateUrl : "error.html"
    });
});





/*press services & controllers*/
sr_app.service('srPressService', function(){
	return {
		getAllOrders:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {allOrders:pressStaticData.allOrders, dealerList:dbStaticData.dealerList}
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getCreateOrderData:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {pressList:dbStaticData.pressList,productList:dbStaticData.productList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		}
	};
});
sr_app.controller('srPressOrderListAllController',
				["$scope", '$http','$q','srPressService',
                 function($scope, $http, $q, srPressService){
	srAngCntxt = {scope:$scope, http:$http, srPressService:srPressService, q:$q};
	srPressOrderListAllControllerJS.init();
}]);

sr_app.controller('srPressOrderCreate',
		["$scope", '$http','$q','srPressService',
         function($scope, $http, $q, srPressService){
srAngCntxt = {scope:$scope, http:$http, srPressService:srPressService, q:$q};
srPressOrderCreateJS.init();
}]);

/*customer services & controllers*/
sr_app.service('srCustService', function(){
	return {
		getAllOrders:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {allOrders:custStaticData.allOrders, dealerList:dbStaticData.dealerList}
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getCreateOrderData:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {custList:dbStaticData.custList, productList:dbStaticData.productList
									, dealerList:dbStaticData.dealerList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		}
	};
});
sr_app.controller('srCustOrderListAllController',
				["$scope", '$http','$q','srCustService',
                 function($scope, $http, $q, srCustService){
	srAngCntxt = {scope:$scope, http:$http, srCustService:srCustService, q:$q};
	srCustOrderListAllControllerJS.init();
}]);

sr_app.controller('srCustOrderCreate',
		["$scope", '$http','$q','srCustService',
         function($scope, $http, $q, srCustService){
srAngCntxt = {scope:$scope, http:$http, srCustService:srCustService, q:$q};
srCustOrderCreateJS.init();
}]);

/*admin services and controllers*/
sr_app.service('srAdminService', function(){
	return {
		getDealerList:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {dealerList:dbStaticData.dealerList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getInventoryDet:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {inventoryList:dbStaticData.inventory};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getPressListFullDet:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {pressList:dbStaticData.pressFullDetList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getCustListFullDet:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {custList:dbStaticData.custFullDetList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getDealerListFullDet:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {dealerList:dbStaticData.dealerFullDetList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getProductListFullDet:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {productList:dbStaticData.productList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		},
		getExpenditureListFullDet:function(){
			 var df = srAngCntxt.q.defer();
			 var staticData = {expenditureList:dbStaticData.expenditureList};
			 srAngCntxt.http({method : "GET", url : "data.txt"}).then(function success(response) {
				 	//df.resolve({"data":response.data});
				 	df.resolve({"data":staticData});
			   }, function error(response) {
				   //df.reject(response.statusText);
				   df.resolve({"data":staticData});
			   });
			 return df.promise;
		}
	};
});
sr_app.controller('srAdminAddProduct',
		["$scope", '$http','$q',
         function($scope, $http, $q){
srAngCntxt = {scope:$scope, http:$http, q:$q};
srAdminAddProductJS.init();
}]);

sr_app.controller('srAdminAddExpenses',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminAddExpensesJS.init();
}]);
sr_app.controller('srAdminInventory',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminInventoryJS.init();
}]);
sr_app.controller('srAdminPressList',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminPressListJS.init();
}]);
sr_app.controller('srAdminCustList',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminCustListJS.init();
}]);
sr_app.controller('srAdminDealerList',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminDealerListJS.init();
}]);
sr_app.controller('srAdminProductList',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminProductListJS.init();
}]);
sr_app.controller('srAdminMiscExpnsList',
		["$scope", '$http','$q','srAdminService',
         function($scope, $http, $q, srAdminService){
srAngCntxt = {scope:$scope, http:$http, srAdminService:srAdminService, q:$q};
	srAdminMiscExpnsListJS.init();
}]);











