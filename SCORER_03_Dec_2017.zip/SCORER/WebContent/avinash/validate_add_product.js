function validate()
{
   if( document.ProductRegistration.name.value == "" )
   {
     alert( "Please provide your Product Name!" );
     document.PressRegistration.name.focus() ;
     return false;
   }

   /*if( document.ProductRegistration.author.value == "" )
   {
     alert( "Please provide your Author!" );
     document.PressRegistration.author.focus() ;
     return false;
   }*/
   return( true );
}
