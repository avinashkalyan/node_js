function validate()
{
  if( document.OrdersToPress.orderDate.value == "" )
  {
    alert( "Please provide order date!" );
    document.OrdersToPress.orderDate.focus() ;
    return false;
  }
  if( document.OrdersToPress.pressName.value == "" )
  {
    alert( "Please provide press name!" );
    document.OrdersToPress.pressName.focus() ;
    return false;
  }
   if( document.OrdersToPress.name.value == "" )
   {
     alert( "Please provide Person Name who has received your order!" );
     document.OrdersToPress.name.focus() ;
     return false;
   }


   return( true );
}
